'''
William Purcell
Turtlebot Capstone 
8/7/2024

Notes:
Navigate the Maze with Turtlebot using methods defined in robot_control_class.py

'''



'''
using the following methods:
rc.get_laser (direction)
rc.get_laser_full()
rc.move_straight()
rc.stop_robot()
rc.move_straight_time(motion, speed, time)
rc.turn (clockwise, speed, time)
rc.rotate (degrees)
'''

from robot_control_class import RobotControl
rc=RobotControl()


while(1):
    front_laser=rc.get_laser(360)
    all_laser=rc.get_laser_full()

    if (front_laser > max(all_laser)-1):      #if there is enough space forward go forward
        while(front_laser> .5):
            rc.move_straight_time("forward", 1, .2)
            front_laser=rc.get_laser(360)

    elif(rc.get_laser(719)>rc.get_laser(1)): #if there is more space to the left turn left
        rc.stop_robot()
        rc.rotate (20)

    else:                                   #if there is more space to the right turn right
        rc.stop_robot()
        rc.stop_robot()
        rc.rotate (-20)




