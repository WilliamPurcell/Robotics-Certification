from robot_control_class import RobotControl
rc= RobotControl()
lasers=rc.get_laser_full()

print("Right:", lasers[0], ", Front:", lasers[360], ", Left:", lasers[719], 'm')

