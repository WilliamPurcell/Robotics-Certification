from robot_control_class import RobotControl
rc=RobotControl()
lasers=rc.get_laser_full()

laser_dict= {'P0': lasers[0], "P100": lasers[100],'P200': lasers[200], "P300": lasers[300],'P400': lasers[400], "P500": lasers[500],'P600': lasers[600], 'P719':lasers[719]}
print (laser_dict)