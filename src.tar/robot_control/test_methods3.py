from robot_control_class import RobotControl

rc = RobotControl(robot_name="summit")


rc.move_straight_time ("forward", .5, 2)

rc.turn('clockwise', .3, 6)