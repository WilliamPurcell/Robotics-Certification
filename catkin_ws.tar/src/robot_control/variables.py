from robot_control_class import RobotControl
rc=RobotControl()

laser_value=250
laser1=rc.get_laser(laser_value)
print('Laser ',laser_value, " = ", laser1, " m.")

laser_value=360
laser2=rc.get_laser(laser_value)
print('Laser ',laser_value, " = ", laser2, " m.")

laser_value=450
laser2=rc.get_laser(laser_value)
print('Laser ',laser_value, " = ", laser2, " m.")

