name = input("What's your name? ")
print("Nice to meet you, " + name)
age = int(input("What's your age? "))

age2 = age + 1

print("So next year you will be %d years old!" % age2)