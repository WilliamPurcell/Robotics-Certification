from robot_control_class import RobotControl
rc=RobotControl()
laser = int(input("What laser would you like? Laser 1-720 \n"))-1 #account for 0 index
laser_value=rc.get_laser(laser)
print("Distance from ",laser+1, " is ",laser_value, "m." )